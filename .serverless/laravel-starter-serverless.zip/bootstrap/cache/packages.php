<?php return array(
    'nesbot/carbon' =>
        array(
            'providers' =>
                array(
                    0 => 'Carbon\\Laravel\\ServiceProvider',
                ),
        ),
);
